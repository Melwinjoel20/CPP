class RateLimitExceeded(Exception):
    pass
